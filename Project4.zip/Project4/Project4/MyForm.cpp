#include "MyForm.h"

using namespace System;
using namespace System::Windows::Forms;


[STAThreadAttribute]
int main(array<String^>^ args)
{
	int a, b;
	float c, d;

	Application::EnableVisualStyles();
	Application::SetCompatibleTextRenderingDefault(false);

	Project4::MyForm form;
	Application::Run(%form);
	return 0;

//	obj.sum(a,b);
//	obj.sum(c,d);
	/*
	int addition:sum(int, int)
	{
		return a + b;
		// do some stuffs here
	}
	*/
}
/*
class addition
{
	int sum(int a, int b)
	{	
		return a + b;
	}
	float sum(float c, float d)
	{
		return c + d;
	}
}obj;

*/




